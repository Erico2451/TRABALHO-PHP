<?php


include "../adm/controle.php";
include "../adm/seguranca_adm.php";

?>
<div class="container p-5">
    <div class="row text-center quadro">
        <div class="col-12 col-md-6">
            <a href="">
                <img src="" alt="">
                <p>USUARIO</P>
</a>
</div>

<div class="col-12 col-md-6">
            <a href="">
                <img src="" alt="">
                <p>ADM</p>
</a>
</div>

<div class="col-12 col-md-6">
            <a href="">
                <img src="" alt="">
                <p>EDITAR</p>
</a>
</div>

<div class="col-12 col-md-6">
            <a href="">
                <img src="" alt="">
                <p>PRODUTO</p>
</a>
</div>
</div>
